const Logger = require('./logger')

async function testarLogger() {
    console.log(`Iniciando teste do Logger.`)

    const logger = new Logger('app.log')

    await logger.info('Aplicacao iniciado com sucesso');
    await logger.error('Esta é uma mensagem de erro');
    await logger.warn('Esta é uma mensagem de aviso');

    console.log('Teste concluido! Verifique o arquivo app.log');
}

testarLogger();