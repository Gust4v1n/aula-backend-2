const fs = require('fs').promises;

async function lerMeuArquivo(){
    try{
        console.log('Robo: "Vou tentar ler o arquivo dados.txt..."')
        const conteudo = await fs.readFile('dados.txt', 'utf8')

        console.log('Robo: "Consegui ler, Aqui esta"')
        console.log('Conteudo que o robo encontrou:')
        console.log('-'.repeat(30));
        console.log(conteudo);
        console.log('-'.repeat(30));
    }
    catch (error){
        console.log('Ops, Deu problema: ', error.message)
        if(error.code === 'ENOENT'){
            console.log('Robo: "O aquivo dados.txt nao existe"');
        }
    }
}

async function escreverMeuArquivo(){
    try{
        console.log('Criando um novo arquivo...')
        const meuTexto = `Arquivo criado pelo Node.Js!
Data: ${new Date().toLocaleString()}`

        await fs.writeFile('arquivo-criado.txt', meuTexto, 'utf8')

        console.log('arquivo criado com sucesso')
        console.log('conteudo do arquivo criado')
        console.log('-'.repeat(30))
        console.log(meuTexto)
        console.log('-'.repeat(30))
    }
    catch(error){
        console.log('ops, deu problema: ', error.message)
    }
}

async function verificarArquivo(nome){
    try{
        await fs.access(nome)
        console.log(`arquivo ${nome} existe`)
        return true
    }
    catch(error){
        console.log(`arquivo ${nome} não existe, erro:`, error.message)
    }
}

async function testarArquivos(){
    console.log('Testando arquivos\n')
    const arquivos = [
        'dados.txt',
        'arquivo-criado.txt',
        'arquivo-inexistente.txt',
        'package.json'
    ]

    for(const arquivo of arquivos){
        await verificarArquivo(arquivo)
        console.log('')
    }
    console.log("\nVerificacao concluida")
}

lerMeuArquivo();
escreverMeuArquivo();
testarArquivos();