const fs = require('fs').promises

async function criarPasta(nomePasta){
    try{
        console.log(`Criando pasta "${nomePasta}"`)
        await fs.mkdir(nomePasta)
        console.log('Pasta criada com sucesso')
    }
    catch(error){
        if(error.code === 'EEXIST'){
            console.log(`A pasta ${nomePasta} ja existe`)
        }
        else{
            console.error('Erro ao criar a pasta', error.message)
        }
    }
}

async function listarArquivos(nomePasta){
    try{
        console.log(`Listando arquivos da pasta ${nomePasta}`)
        const arquivos = await fs.readdir(nomePasta)

        if(arquivos.lengt === 0){
            console.log('Pasta vazia')
        }
        else{
            arquivos.forEach((arquivos, index) =>{
                console.log(`${index+1}. ${arquivos}`)
            })
        }
    }
    catch(error){
        console.error('erro ao listar pasta: ', error.message)
    }
}

async function exemplocomPastas(){
    console.log('Trabalhando com pastas\n')
    await criarPasta('minha-pasta-teste')
    console.log('')

    await listarArquivos('.')
    console.log('')

    await listarArquivos('minha-pasta-teste')
    console.log('\nTeste concluido')
}
exemplocomPastas();