const math = require('./math.js')

console.log('UM LINDO TESTE DA FUNCAO HIPER MEGA BLASTER ZIKA\n');

resultadosoma = math.soma(1, 4);
console.log(`Resultado da soma: ${resultadosoma}`);

resultadodamultiplicacao = math.multiplicacao(2, 5);
console.log(`Resultado da multiplicacao: ${resultadodamultiplicacao}`);

resultadodadivisao = math.divisao(10,2);
console.log(`Resulado da divisao: ${resultadodadivisao}`);

resultadodasubtracao = math.subtracao(30, 15);
console.log(`Resultado da subtracao: ${resultadodasubtracao}`)

testedivisaoporzero = math.divisao(0, 15);
console.log(`Resultado da divisão por zero: ${testedivisaoporzero}`)

console.log('\nTeste concluido')