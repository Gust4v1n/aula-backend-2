function soma(a,b){
    console.log('Somando...')
    return a + b;
}

function multiplicacao(a,b){
    console.log('Multiplicando...')
    return a * b;
}

function divisao(a,b){
    if(a === 0 || b === 0){
        console.log('Não é possivel dividir por 0')
        return null;
    }
    console.log('Dividindo...');
    return a/b;
}

function subtracao(a,b){
    console.log('Subtraindo');
    return a - b
}

module.exports = {
    soma,
    multiplicacao,
    divisao,
    subtracao
}