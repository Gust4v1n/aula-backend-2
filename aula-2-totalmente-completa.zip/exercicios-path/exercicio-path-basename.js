const path = require('path')

console.log('extraindo informacoes\n')
const arquivoCompleto = '/home/usuario/projetos/meu-app/src/index.js'
console.log('Caminho original: ', arquivoCompleto)
console.log('')

const nomeArquivo = path.basename(arquivoCompleto)
console.log('Nome Completo: ', nomeArquivo)

const nomesemextensao = path.basename(arquivoCompleto, '.js')
console.log('Nome sem extensao: ', nomesemextensao)

const nomecomextensao = path.extname(arquivoCompleto)
console.log('Pasta com extencao: ', nomecomextensao)

const pastaPai = path.dirname(arquivoCompleto)
console.log('Pasta Pai: ', pastaPai)

function analisarArquivo(caminhoArquivo){
    console.log(`Analisando ${caminhoArquivo}`)
    console.log('-'.repeat(50))
    console.log(`Nome Completo: `, path.basename(caminhoArquivo))
    console.log(`Nome Sem ext.: `, path.basename(caminhoArquivo, path.extname(caminhoArquivo)))
    console.log(`Extensao: `, path.extname(caminhoArquivo))
    console.log(`Pasta: `, path.dirname(caminhoArquivo))
    console.log(`Absoluto: `, path.resolve(caminhoArquivo))
}

analisarArquivo('documento.pdf')
analisarArquivo('fotos/ferias.jpg')
analisarArquivo('../backup/dados.json')
analisarArquivo('C:\\Users\\João\\Desktop\\apresentacao.pptx')