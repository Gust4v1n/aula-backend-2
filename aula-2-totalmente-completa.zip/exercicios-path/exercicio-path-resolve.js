const path = require('path')

console.log('caminhos absoluto\n')

console.log('pasta atual: ', process.cwd())
console.log('')

const absoluto1 = path.resolve('documentos', 'arquivo.txt')
console.log('Arquivo 1 (absoluto)', absoluto1)

const absoluto2 = path.resolve('..', 'backup', 'dados')
console.log('Arquivo 2 (absoluto): ', absoluto2)

const absoluto3 = path.resolve('/home/usuario/arquivo.txt')
console.log('Arquivo 3 (já absoluto) ', absoluto3)

const configpath = path.resolve('config', 'database.json')
console.log('configuracoes: ', configpath)

console.log('\ndiferenca entre join e resolve')
console.log('join("docs", "file.txt"    :', path.join('docs', 'file.txt'))
console.log('resolve("docs", "file.txt"    :', path.resolve('docs', 'file.txt'))