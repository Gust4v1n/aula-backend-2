const path = require('path');
const fs = require('fs').promises;

async function organizarArquivos() {
    try {
        console.log('ORGANIZADOR DE ARQUIVOS\n');
        
        const arquivos = await fs.readdir('.');
        
        const apenasArquivos = [];
        for (const item of arquivos) {
            const stats = await fs.stat(item);
            if (stats.isFile()) {
                apenasArquivos.push(item);
            }
        }
        
        console.log(`📋 Encontrados ${apenasArquivos.length} arquivos:`);
        
        for (const arquivo of apenasArquivos) {
            const extensao = path.extname(arquivo);
            const nome = path.basename(arquivo, extensao);
            const tamanho = (await fs.stat(arquivo)).size;
            
            console.log(`\n${arquivo}`);
            console.log(`Nome: ${nome}`);
            console.log(`Tipo: ${extensao || '(sem extensao)'}`);
            console.log(`Tamanho: ${tamanho} bytes`);
            
            let pastaDestino;
            switch (extensao.toLowerCase()) {
                case '.jpg':
                case '.png':
                case '.gif':
                    pastaDestino = 'imagens';
                    break;
                case '.pdf':
                case '.doc':
                case '.docx':
                    pastaDestino = 'documentos';
                    break;
                case '.js':
                case '.html':
                case '.css':
                    pastaDestino = 'codigo';
                    break;
                default:
                    pastaDestino = 'outros';
            }
            
            console.log(`Sugestao: mover para pasta "${pastaDestino}"`);
            
            const caminhoFinal = path.join(pastaDestino, arquivo);
            console.log(`caminho final: ${caminhoFinal}`);
        }
        
        console.log('\nAnalise concluida!');
    } catch (error) {
        console.error('erro:', error.message);
    }
}

organizarArquivos();