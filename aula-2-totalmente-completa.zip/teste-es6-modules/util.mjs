export function comprimentar(nome){
    return console.log(`Olá ${nome}, Seja bem vindo ao meu programa hiper mega blaster util`);
}

export function calcularidade(anoNascimento){
    const anoAtual = new Date().getFullYear();
    return anoAtual - anoNascimento;
}

export const PI = 3.14;

export default function byebye(nome){
    return console.log(`Tchau ${nome}, Tenha um otimo dia`)
}