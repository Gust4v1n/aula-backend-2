import { comprimentar, PI, calcularidade } from "./util.mjs";
import byebye from "./util.mjs";

console.log(`Teste da ferramente super util\n`);
console.log(comprimentar('Gustavo'))
const idadezika = calcularidade(2009);
console.log(`Eu nasci em 2009, logo eu tenho ${idadezika} anos`)
console.log(`Valor de PI: ${PI}`)
console.log(byebye(`Gustavo`))

console.log('\nTeste concluido')