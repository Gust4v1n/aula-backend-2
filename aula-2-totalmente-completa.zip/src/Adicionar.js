const Category = require('./models/Category');

const secaoPaes = new Category(
    1,
    'Paes',
    'Paes frescos e quentinhos',
    '🍞'
);

secaoPaes.addProduct()