const Product = require('./models/Product');

const paoFrances = new Product(
    1,                           
    'Pão Francês',
    'Pão fresquinho do dia',
    0.50,
    1,
    'pao-frances.jpg'
);

console.log('Preço bonitinho:', paoFrances.getFormattedPrice());
console.log('Está disponível?', paoFrances.isAvailable());